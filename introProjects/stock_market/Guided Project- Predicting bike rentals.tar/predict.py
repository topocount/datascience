# usings pandas 0.15.2
import numpy as np
import pandas as pd
from datetime import datetime as dt

mkt = pd.read_csv('sphist.csv')
mkt['Date'] = pd.to_datetime(mkt['Date'])
mkt.sort('Date', ascending=True,inplace=True)
#print(mkt.head(1))

#Generating Indicators
#first date: 1950-01-03
first_day = dt.strptime('1951-01-03','%Y-%m-%d')

avg_365 = pd.rolling_mean(mkt['Close'],365).shift(1)
avg_5 = pd.rolling_mean(mkt['Close'],5).shift(1)
avg_30 = pd.rolling_mean(mkt['Close'],30).shift(1)
std_30 = pd.rolling_std(mkt['Close'],30).shift(1)

mkt['avg_5'] = avg_5
mkt['avg_365'] = avg_365
mkt['avg_30'] = avg_30
mkt['std_30'] = std_30

mkt['wk_to_yr'] = mkt['avg_5']/mkt['avg_365']
mkt = mkt[mkt['Date'] >= first_day]
mkt.dropna(inplace=True)
# The Dataset now contains a rolling five and 365 day average
# along with a five day to 365 day closing price ratio

# Splitting the data into a training and test set
train = mkt[mkt['Date'] < dt.strptime('2013-01-01','%Y-%m-%d')]
test = mkt[mkt['Date'] >= dt.strptime('2013-01-01','%Y-%m-%d')]

# Error measure chosen: MAE, so it is easy to see the distance between
# the projection and the error
from sklearn.linear_model import LinearRegression
mktreg = LinearRegression()
fit_columns = ['avg_5','avg_365','wk_to_yr','avg_30','std_30']
mktreg.fit(train[fit_columns], train['Close'])
preds = mktreg.predict(test[fit_columns])
from sklearn.metrics import mean_absolute_error
print('mean absolute error: ',mean_absolute_error(test['Close'],preds))
